package com.example.stock;

import com.example.stock.config.AppConfig;
import com.example.stock.constant.AppConstant;
import com.example.stock.helper.UnitTestHelper;
import com.example.stock.init.InitializerV3;
import com.example.stock.serialization.AppSerdes;
import com.example.stock.util.AppUtils;
import com.fasterxml.jackson.databind.JsonNode;
import io.confluent.common.utils.Utils;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.TestInputTopic;
import org.apache.kafka.streams.TopologyTestDriver;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

public class MovingAverageTopologyTestV3 {

	private TestInputTopic<String, JsonNode> inputTopic = null;

	private TopologyTestDriver testDriver;

	@Before
	public void setup() throws Exception {

		InitializerV3 initializer = new InitializerV3();
		AppConfig.getInstance().setStreamConfig(
				AppUtils.getProperties(getClass().getClassLoader().getResource("test-moving-average-stream-application.properties")
						.getPath()));
		AppConfig.getInstance().setLogConfig(AppUtils.getProperties(
				getClass().getClassLoader().getResource("test-moving-average-stream-log4j.properties")
						.getPath()));

		initializer.initStreams();

		testDriver = new TopologyTestDriver(initializer.getTopology(), AppConfig.getInstance().getStreamConfig());
		inputTopic = testDriver.createInputTopic(
				AppConfig.getStreamConfigProperty(AppConstant.INPUT_TOPIC),
				Serdes.String().serializer(), AppSerdes.jsonNode().serializer());


	}

	@After
	public void after() throws IOException, URISyntaxException {
		try {
			testDriver.close();
		} catch (Exception exception) {
			String normalized = new URI(AppConfig.getInstance().getStreamConfig().getProperty(AppConstant.STATE_DIR))
					.normalize().getPath();
			Utils.delete(new File(normalized));
		}
	}

	@SuppressWarnings("unchecked")
	@Test
	public void testData1() throws IOException {
		UnitTestHelper.populateInputTopic(inputTopic, "/data/test-data-1.json");
 	}

}
