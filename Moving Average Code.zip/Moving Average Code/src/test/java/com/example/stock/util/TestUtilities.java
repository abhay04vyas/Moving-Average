package com.example.stock.util;

import com.fasterxml.jackson.databind.JsonNode;
import org.apache.avro.Schema;
import org.apache.avro.generic.GenericDatumReader;
import org.apache.avro.generic.GenericRecord;
import org.apache.avro.io.Decoder;
import org.apache.avro.io.DecoderFactory;

import java.io.IOException;

public class TestUtilities {

    public static TestUtilities testUtilities;
    public static TestUtilities getInstance(){
        if (testUtilities == null){
            testUtilities = new TestUtilities();
        }
        return testUtilities;
    }
    public GenericRecord getGenericRecordReader(JsonNode valueNode, String schemaFilePath) throws IOException {
        Schema valueSchema = new Schema.Parser().parse(getClass().getResourceAsStream(schemaFilePath));
        DecoderFactory decoderFactory = new DecoderFactory();
        Decoder decoder = decoderFactory.jsonDecoder(valueSchema, valueNode.toString());
        GenericDatumReader<GenericRecord> reader = new GenericDatumReader<>(valueSchema);
        GenericRecord recordValue = reader.read(null, decoder);
        return recordValue;
    }
}
