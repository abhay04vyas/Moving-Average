package com.example.stock.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.streams.TestInputTopic;

import java.io.IOException;
import java.io.InputStream;

public class UnitTestHelper {



    public static void populateInputTopic(TestInputTopic<String, JsonNode> sessionTopic,String filePath) throws IOException {
        InputStream activityStream = UnitTestHelper.class.getResourceAsStream(filePath);

        ObjectMapper mapper = new ObjectMapper();
        JsonNode valuesNode = mapper.readTree(activityStream);
        int i=0;
        for (JsonNode jsonNode : valuesNode) {
            JsonNode valueNode = jsonNode.get("value");
            JsonNode keyNode = jsonNode.get("key");

            sessionTopic.pipeInput(keyNode.toString(), valueNode);
         }


    }


}
