package com.example.stock.init;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.Transformer;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.OptionalDouble;

public class EMAProcessor implements Transformer<String, JsonNode, KeyValue<String, JsonNode>> {

    private ProcessorContext context;
    private Integer noOfSamples;
    private String storeFieldName;
    private String outputFieldName;
    private String riskScoreStoreName;
    private KeyValueStore<String, String> riskScoreStore;
    private Double alpha;
    public static final String STRING_DASH="-";

    public EMAProcessor(final Double alpha, final String outputFieldName, final String storeFieldName, final String stateStoreName) {
        this.alpha = alpha;
        this.outputFieldName = outputFieldName;
        this.riskScoreStoreName = stateStoreName;
        this.storeFieldName = storeFieldName;
    }

    @Override
    public void init(ProcessorContext context) {
        this.context = context;
        this.riskScoreStore = (KeyValueStore<String, String>) context.getStateStore(this.riskScoreStoreName);

    }

    @Override
    public KeyValue<String, JsonNode> transform(String s, JsonNode jsonNode) {

        String oldValue = riskScoreStore.get(storeFieldName);
        Double previousValue = null;
        if(oldValue == null) {
            previousValue = 0.0;
        }else{
            previousValue = Double.valueOf(oldValue);
        }
        Double riskScore = jsonNode.get("Risk_Score").asDouble();

        // Now calculate the new moving average.
        Double newAvg = alpha * riskScore +
                (1 - alpha) * previousValue;
        newAvg = formatAverage(newAvg);
        // Update the state store.
        riskScoreStore.put(storeFieldName, newAvg.toString());

        ((ObjectNode) jsonNode).put(outputFieldName,newAvg);
        return new KeyValue<>(s,jsonNode);

    }



    private String trackRiskScore(String riskScoresCSV,Double riskScore){
        //System.out.println("MovingAverageTransformer.trackRiskScore");
        //System.out.println("riskScoresCSV = " + riskScoresCSV + ", riskScore = " + riskScore);
        if(!StringUtils.isEmpty(riskScoresCSV) ){
            riskScoresCSV = riskScoresCSV.strip();
            String[] items = riskScoresCSV.split(",");
            if(items.length<noOfSamples){
                return StringUtils.join(riskScoresCSV,","+Double.toString(riskScore));
            }else{
                return riskScoresCSV.replaceFirst("^\\d*\\.?\\d*,","") + ","+Double.toString(riskScore);
            }
        }
        return Double.toString(riskScore);
    }

    private Double calculateMovingAverage(String riskScores){
        //System.out.println("MovingAverageTransformer.calculateMovingAverage");
        //System.out.println("riskScores = " + riskScores);

        if(!StringUtils.isEmpty(riskScores)){
            String[] items = riskScores.split(",");
            if(items.length<noOfSamples){
                return null;
            }else{
                OptionalDouble movingAverage =  Arrays.stream(items).mapToDouble(Float::valueOf).average();
                return movingAverage.isPresent()?formatAverage(movingAverage.getAsDouble()):null;
            }
        }
        return null;
    }

    private static Double formatAverage(Double numberToFormat){
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        return  Double.valueOf(df.format(numberToFormat));
    }

    @Override
    public void close() {

    }

}