package com.example.stock.init;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.kstream.Transformer;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.OptionalDouble;

public class MovingAverageTransformer implements Transformer<java.lang.String, JsonNode, KeyValue<String, JsonNode>> {

    private ProcessorContext context;
    private Integer noOfSamples;
    private String storeFieldName;
    private String outputFieldName;
    private String riskScoreStoreName;
    private KeyValueStore<String, String> riskScoreStore;
    public static final String STRING_DASH="-";

    public MovingAverageTransformer(final Integer noOfSamples,final String outputFieldName,final String storeFieldName,final String stateStoreName) {
        this.noOfSamples = noOfSamples;
        this.outputFieldName = outputFieldName;
        this.riskScoreStoreName = stateStoreName;
        this.storeFieldName = storeFieldName;
    }

    @Override
    public void init(ProcessorContext context) {
        this.context = context;
        this.riskScoreStore = (KeyValueStore<String, String>) context.getStateStore(this.riskScoreStoreName);

    }

    @Override
    public KeyValue<String, JsonNode> transform(String s, JsonNode jsonNode) {

        String riskScoresCSV = riskScoreStore.get(storeFieldName);
        //System.out.println("riskScoresCSV = " + riskScoresCSV);

        //System.out.println("jsonNode = " + jsonNode);
        riskScoresCSV = trackRiskScore(riskScoresCSV,jsonNode.get("Risk_Score").asDouble());

        riskScoreStore.put(storeFieldName,riskScoresCSV);
        Double movingAverage = calculateMovingAverage(riskScoresCSV);
        System.out.println("movingAverage = " + movingAverage);
        if(movingAverage==null){
            ((ObjectNode) jsonNode).set(outputFieldName,null);
            return new KeyValue<>(s,jsonNode);
        }

        ((ObjectNode) jsonNode).put(outputFieldName,movingAverage);
        return new KeyValue<>(s,jsonNode);

    }

    private String trackRiskScore(String riskScoresCSV,Double riskScore){
        //System.out.println("MovingAverageTransformer.trackRiskScore");
        //System.out.println("riskScoresCSV = " + riskScoresCSV + ", riskScore = " + riskScore);
        if(!StringUtils.isEmpty(riskScoresCSV) ){
            riskScoresCSV = riskScoresCSV.strip();
            String[] items = riskScoresCSV.split(",");
            if(items.length<noOfSamples){
                return StringUtils.join(riskScoresCSV,","+Double.toString(riskScore));
            }else{
                return riskScoresCSV.replaceFirst("^\\d*\\.?\\d*,","") + ","+Double.toString(riskScore);
            }
        }
        return Double.toString(riskScore);
    }

    private Double calculateMovingAverage(String riskScores){
        //System.out.println("MovingAverageTransformer.calculateMovingAverage");
        //System.out.println("riskScores = " + riskScores);

        if(!StringUtils.isEmpty(riskScores)){
            String[] items = riskScores.split(",");
            if(items.length<noOfSamples){
                return null;
            }else{
                OptionalDouble movingAverage =  Arrays.stream(items).mapToDouble(Float::valueOf).average();
                return movingAverage.isPresent()?formatAverage(movingAverage.getAsDouble()):null;
            }
        }
        return null;
    }

    private static Double formatAverage(Double numberToFormat){
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        return  Double.valueOf(df.format(numberToFormat));
    }

    @Override
    public void close() {

    }

}