package com.example.stock.util;

import io.confluent.common.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class AppUtils {

    private final static Logger log = LoggerFactory.getLogger(AppUtils.class);


    public static void cleanDirectory(String filePath) throws IOException {
        Utils.delete(new File(filePath));
    }

    public static Properties getProperties(String filePath) throws IOException {
        Properties properties = new Properties();
        properties.load(new FileInputStream(filePath));
        return properties;
    }


}