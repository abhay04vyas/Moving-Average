package com.example.stock.util;

import java.util.Properties;

import com.example.stock.config.AppConfig;
import com.example.stock.constant.AppConstant;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class KafkaUtils {
    private static final Logger log = LoggerFactory.getLogger(KafkaUtils.class);

    private final KafkaProducer<String, String> producer;
    private final String DEFAULT_PRODUCER_PROTOCOL = "PLAINTEXT";
    private final String PRODUCER_PREFIX = "producer.";

    public KafkaUtils(Properties streamProps){
        Properties props = new Properties();
        props.put("acks", "all");
        props.put("retries", 0);
        props.put("batch.size", 16384);
        props.put("linger.ms", 1);
        props.put("buffer.memory", 33554432);
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");


        String bootstrapServers = AppConfig.getInstance().getStreamConfig().getProperty(AppConstant.BOOTSTRAP_SERVERS_CONFIG);

        if(bootstrapServers.startsWith(DEFAULT_PRODUCER_PROTOCOL)){
            props.put(AppConstant.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        } else{
            props.put(AppConstant.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
            for(Object keyObj : streamProps.keySet()){
                String key = (String) keyObj;
                if(key.startsWith(PRODUCER_PREFIX)){
                    props.put(key.replaceAll(PRODUCER_PREFIX, ""), streamProps.get(key));
                }
            }
        }
        log.debug("Listing producer properties: " + props);

        producer = new KafkaProducer<String, String>(props);
    }


}
