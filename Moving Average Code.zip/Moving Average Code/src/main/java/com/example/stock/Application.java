package com.example.stock;

import com.example.stock.init.InitializerV1;

public class Application {

    public static void main( String[] args ) throws Exception
    {
        new InitializerV1().run(args);
    }
}