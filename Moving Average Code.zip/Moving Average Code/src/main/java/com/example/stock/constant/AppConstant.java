package com.example.stock.constant;

public class AppConstant {
    public static final String INPUT_TOPIC="input.topic";
    public static final String RISK_SCORE_STORE_NAME ="risk-score-data-store";
 	public static final String STATE_DIR="state.dir";
    public static final String BOOTSTRAP_SERVERS_CONFIG = "bootstrap.servers";

}
