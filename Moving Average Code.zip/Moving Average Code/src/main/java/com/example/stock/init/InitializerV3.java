package com.example.stock.init;

import com.example.stock.config.AppConfig;
import com.example.stock.constant.AppConstant;
import com.example.stock.serialization.AppSerdes;
import com.example.stock.util.AppUtils;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.http.util.Asserts;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Named;
import org.apache.kafka.streams.kstream.Printed;
import org.apache.kafka.streams.state.KeyValueStore;
import org.apache.kafka.streams.state.StoreBuilder;
import org.apache.kafka.streams.state.Stores;
import org.apache.log4j.PropertyConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class InitializerV3 {

    private final Logger LOG = LoggerFactory.getLogger(InitializerV3.class);

    private Topology topology = null;

    public void run(String[] args) throws Exception {
        /*
         * Receive the arguments and convert to list of string
         */
        List<String> arguments = Optional.ofNullable(args).map(item -> Arrays.asList(args))
                .orElseThrow(() -> new Exception("Arguments cannot be null/empty"));

		/*
		 * Should be equal to 2 arguments
		 */
		if (arguments.size() == 2) {
			AppConfig.getInstance().setStreamConfig(AppUtils.getProperties(arguments.get(0)));
			AppConfig.getInstance().setLogConfig(AppUtils.getProperties(arguments.get(1)));
 		} else {
			System.out.println(
					"USAGE: moving-average-stream.jar streams-config.properties log4j.properties");
			Runtime.getRuntime().exit(0);
		}


        // initialize log4j
        initLogger();
        LOG.info("Application initialized!");

        // clean the local directory
        cleanDir();
        //LOG.info("Directory cleaned!");

        // initialize the stream
        initStreams();
        LOG.info("Streams initalized!");

        startStreams();
        LOG.info("Streams Started!");
    }

    private void startStreams() throws Exception {

        Asserts.notNull(topology, "Topology");

        // print the topology
        LOG.info("topology {}", topology.describe());
        // apply the stream config
        KafkaStreams streams = new KafkaStreams(topology, AppConfig.getInstance().getStreamConfig());
        System.out.println("topology = " + streams);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOG.info("Shutting down servers");
            streams.close();
        }));

        //streams.cleanUp();
        streams.start();
        System.out.println("streams.toString() = " + streams);
    }

    private void cleanDir() throws IOException, URISyntaxException {
		String normalized = new URI(AppConfig.getInstance().getStreamConfig().getProperty("state.dir")).normalize()
				.getPath();
		AppUtils.cleanDirectory(normalized);
	}

    private void initLogger() {
        PropertyConfigurator.configure(AppConfig.getInstance().getLogConfig());
    }

    public void initStreams() throws Exception {

        final StreamsBuilder builder = new StreamsBuilder();

        //Create State Store to the Risk Score
        final StoreBuilder<KeyValueStore<String, String>> storeBuilder = Stores.keyValueStoreBuilder(
                Stores.persistentKeyValueStore(AppConstant.RISK_SCORE_STORE_NAME), Serdes.String(), Serdes.String());
        builder.addStateStore(storeBuilder);

        builder.stream(AppConfig.getStreamConfigProperty(AppConstant.INPUT_TOPIC),
                        Consumed.with(Serdes.String(),AppSerdes.jsonNode()).withName("READ_INPUT_TOPIC")
        )
        .transform(() -> new MovingAverageTransformer(4,"MA50","risk_score_50",AppConstant.RISK_SCORE_STORE_NAME),
                Named.as("PERFORM_MOVING_AVERAGE_COMPUTATION_50"),
                AppConstant.RISK_SCORE_STORE_NAME
        ).transform(() -> new MovingAverageTransformer(2,"MA100","risk_score_100",AppConstant.RISK_SCORE_STORE_NAME),
                        Named.as("PERFORM_MOVING_AVERAGE_COMPUTATION_100"),
                        AppConstant.RISK_SCORE_STORE_NAME
        )
        .print(Printed.toSysOut());

        this.topology = builder.build();
    }

    public Topology getTopology() {
        Asserts.notNull(topology, "Topology");
        return topology;
    }
}
