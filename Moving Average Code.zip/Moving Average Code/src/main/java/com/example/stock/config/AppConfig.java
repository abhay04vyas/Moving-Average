package com.example.stock.config;

import java.util.Properties;

public class AppConfig {
	private static AppConfig config;

	// kafka stream properties
    private Properties streamConfig;
    
    // log4j properties
    private Properties logConfig;

    public AppConfig() {

    }

    public static String getStreamConfigProperty(String propertyKey){
        return config.getStreamConfig().getProperty(propertyKey);
    }

    public static AppConfig getInstance() {
        if (config == null) {
            config = new AppConfig();
        }
        return config;
    }

    public Properties getStreamConfig() {
        return streamConfig;
    }

    public void setStreamConfig(Properties streamConfig) {
        this.streamConfig = streamConfig;
    }

    public Properties getLogConfig() {
        return logConfig;
    }

    public void setLogConfig(Properties logConfig) {
        this.logConfig = logConfig;
 
    }
      
}
